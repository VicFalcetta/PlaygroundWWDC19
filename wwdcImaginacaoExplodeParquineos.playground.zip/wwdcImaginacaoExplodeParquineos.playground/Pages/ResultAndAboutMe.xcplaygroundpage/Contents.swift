//: [Previous](@previous)
//: ## Our Drawings are different!:
//: See! It was very unlikely that our drawings would be equal. This is due to the power of imagination and of abstracting things to come up with ideas. Even though we had the same amount of time, the same resources and even the same sound reference, our drawings were different, maybe it was just a small detail or two completely different drawings. That is the power of imagination, every one has it, and even with the same sources of inspiration, different people will come up with different ideas, so even if you wonder that your our someone's imagination will be enough, remember that our creative universe is limitless, and different backgrounds and minds will come up with different ideas.

//: ## About me:
//: Hello, my name is Victor Falcetta, I am a student of University Mackenzie. My major is Computer Science, although I am not so good at coding (and know that there are some mistakes or optimizations that would make my code cleaner), I love everything about the digital world, simply due to the fact that is a gateway to a whole new universe.
//: Besides studying computer stuff, logic, and numbers, I am also a black belt at Judo and Jiu Jitsu, and currently I am a Judo instructor at Colégio Nossa Senhora de Sion, most of the time I am teaching children Judo and its philosophy. Also, I love creating poems as a hobby and creating stories, currently I think I have created over 30 poems, some even in English. That is why it was very special this playground to me, because it works with something that is part of my soul and personality, which is Imagination.


//: ## Credits and Copyright:
//: The sound file and it's sounds were gathered and remixed personally for me by myself with a huge help from my friend Patrick Stefano at his Studio. Everything it is Open Source and of free distribution.
//:Everything else, such as the code and the images were made by me alone, and it's also Open Source and of free distribution and modification.
