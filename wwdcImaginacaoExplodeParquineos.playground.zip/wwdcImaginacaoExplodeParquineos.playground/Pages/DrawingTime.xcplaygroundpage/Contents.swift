//: ## Our Imagination:
//: Even if you wonder that you don't possess, your imagination is one of the most powerful tools as a human being. Things like helicopters, cars or even the wheel come first as a thing or object imagined. Without it, historical personalities such as Leonardo Da Vinci and Wolfgang Amadeus Mozart would have never existed, maybe even our knowledge about Mathmatics and Fisics would be very limited. Some would dare to say that their imagination is very limited and lack all the tools to even abstract the simplest idea. However, I digress with that concept, due to the fact that even with the same sources of inspiration, people will generate different ideas, stories, poems or drawings. So lets prove it that everyone has a creative universe inside their heads and it's unique to each human being.

//: ## Let's test your imagination!:
//: In this simple playground, you will have to draw something on the WHITE FIELD at the BOTTOM (or on the WHITE FIELD that is at the RIGHT side of the Ipad if you place it at horizontal mode) based on the sound ambience track that you will hear as soon as you play start. It can be anything you can think of, just let your mind be free and creativity flow. As soon as you press the Start Buttom, the sound file will play, and timer will be set at 75 seconds and will start counting down. After time is up, you won't be able to draw anymore, and a drawing will pop up on the upper (or leftmost) field. That drawing was made by me, and was drawn at the same time and based on the same ambience sound file. You can compare it and see if we had the same idea and process of imagination, but I dare say that we won't have similar drawings. (For a better experience, use earphones our headphones).

//: [Next](@next)
//#-hidden-code

import Foundation
import SpriteKit
import PlaygroundSupport

//Tamanho (3:4 ou 16:9)
let frame = CGRect(x: 0, y: 0, width: 640, height: 800)
//Cria a view
let sceneView = SKView(frame: frame)
//Cria a cena
let scene = CenaImagine(size: frame.size)


//Modifica a cena, nesse caso o background


    
    
//Apresenta a cena
sceneView.presentScene(scene)
scene.scaleMode = .resizeFill
scene.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
//liveview ->view. É o que faz funcionar as coisas
PlaygroundSupport.PlaygroundPage.current.liveView = sceneView

//#-end-hidden-code
