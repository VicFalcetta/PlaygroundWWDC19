//#-hidden-code

import Foundation
import SpriteKit
import PlaygroundSupport

class CountdownTimer: SKLabelNode{

    var endTime:Date!
    
    func timeLeft() ->TimeInterval{
        //let now = Date()
        let remainingSeconds = endTime.timeIntervalSinceNow
        return max(remainingSeconds,0)
    }
    
    
    
    func update(){
        //converte o tempo atual para um inteiro
        let tempoRestaInt = Int(timeLeft())
        //atualiza o label do timer
        text = String(tempoRestaInt)
    }


    func startWithDuration(duration: TimeInterval){
        let timeNow = Date()
        endTime = timeNow.addingTimeInterval(duration)
    }
    
    func hasFinished() -> Bool{
        
        return timeLeft() == 0
    }
}

//#-end-hidden-code
