
//#-hidden-code
import Foundation
import SpriteKit
import PlaygroundSupport

public class CenaImagine: SKScene{
    
    //Startando as variaveis
    var isMoving:Bool!
    var lastPoint:CGPoint!
    var linha:CGMutablePath!
    
    let campoBaixo: SKSpriteNode! = SKSpriteNode(texture: SKTexture(imageNamed: "CampoDesenhoBaixo"))
    let campoCima: SKSpriteNode! = SKSpriteNode(texture: SKTexture(imageNamed: "CampoDesenhoCima"))
    let campoTimer:SKSpriteNode! = SKSpriteNode(texture: SKTexture(imageNamed: "Timer"))
    let botaoStart:SKSpriteNode! = SKSpriteNode(imageNamed: "StartBotao")
    let desenho1Min:SKSpriteNode! = SKSpriteNode(imageNamed: "Desenho1min")
    let caixaPreta:SKSpriteNode! = SKSpriteNode(imageNamed: "CaixaBloqueadora")
    var sonzineo = SKAction.playSoundFileNamed("AmbienciaDaora", waitForCompletion: true)
    
    let fadeout = SKAction.fadeOut(withDuration: 2)
    
    let startLabel = SKLabelNode()
    
    let timer = CountdownTimer()
    var existenciaStart:Bool = true
    var terminouTempo:Bool = false
  
    // as funcoes necessarias que nao lembro para que
    public override init(size:CGSize){
        super.init(size:size)
    }
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder:aDecoder)
    }
    
    
    public override func sceneDidLoad() {
        self.addChild(campoTimer)
        self.addChild(campoBaixo)
        self.addChild(campoCima)
        self.addChild(botaoStart)
        self.addChild(timer)
        self.addChild(caixaPreta)
        self.addChild(startLabel)
        timer.startWithDuration(duration: 999)
        
    }
    
    //Carrega as coisas para cena
    
    public override func didChangeSize(_ oldSize: CGSize) {
        
        if (size.height > size.width){
            campoTimer.size = CGSize(width: 150, height: 75)
            campoTimer.position.x = size.width/2
            campoTimer.position.y = size.height - campoTimer.size.height/2
            campoTimer.zPosition = 1.0
            
            campoCima.size = CGSize(width: size.width, height: size.height/2)
            campoCima.position.x = size.width/2
            campoCima.position.y = size.height - campoCima.size.height/2
            
            caixaPreta.size = CGSize(width: size.width - size.width * 0.06, height: size.height/2 - size.height * 0.03)
            caixaPreta.position.x = campoCima.position.x
            caixaPreta.position.y = campoCima.position.y
            caixaPreta.zPosition = 0.5
            
            campoBaixo.size = CGSize(width: size.width, height: size.height/2)
            campoBaixo.position.x = size.width/2
            campoBaixo.position.y = campoBaixo.size.height/2
            
            timer.position.x = size.width/2
            timer.position.y = campoTimer.position.y - size.height * 0.02
            timer.zPosition = 1.0
            timer.fontSize = 65
        
            
            
            botaoStart.size = CGSize(width: 260, height:180)
            botaoStart.position.x = size.width/2
            botaoStart.position.y = size.height/2
            botaoStart.zPosition = 1.0
            
            startLabel.fontSize = 70
            startLabel.position.x = botaoStart.position.x
            startLabel.position.y = botaoStart.position.y - size.height * 0.03
            
            startLabel.zPosition = 2.0
            startLabel.horizontalAlignmentMode = .center
            startLabel.fontName = "Arial"
            startLabel.text = "START"
            startLabel.fontColor = UIColor.white
            
            desenho1Min.size = CGSize(width: size.width - size.width * 0.06, height: size.height/2 - size.height * 0.03)
            desenho1Min.position.x = campoCima.position.x
            desenho1Min.position.y = campoCima.position.y
            desenho1Min.zPosition = 0.5
            
            //muda pos linha
            nodeLinha?.position.x = size.width/2
            nodeLinha?.position.y = campoBaixo.size.height/2
            
            

        }
            
        else{
            //resizes das coisas que precisam dar resize
            campoCima.size = CGSize(width: size.width/2, height: size.height)
            campoBaixo.size = CGSize(width: size.width/2, height: size.height)
            caixaPreta.size = CGSize(width: size.width/2 - size.width * 0.03, height: size.height - size.height * 0.06)
            desenho1Min.size = CGSize(width: size.width/2 - size.width * 0.03, height: size.height - size.height * 0.06)
            
            
            //mudando as posicoes das coisas que precisam mudar
            
            campoCima.position.x = campoCima.size.width/2
            campoCima.position.y = campoCima.size.height/2
            campoBaixo.position.x = size.width - campoBaixo.size.width/2
            campoBaixo.position.y = campoBaixo.size.height/2
            
            
            caixaPreta.position.x = campoCima.size.width/2
            caixaPreta.position.y = campoCima.size.height/2
            desenho1Min.position.x = campoCima.position.x
            desenho1Min.position.y = campoCima.position.y
            
            campoTimer.size = CGSize(width: 150, height: 75)
            campoTimer.position.x = size.width/2
            campoTimer.position.y = size.height - campoTimer.size.height/2
            campoTimer.zPosition = 1.0
            
            timer.position.x = size.width/2
            timer.position.y = campoTimer.position.y - size.height * 0.035
            timer.zPosition = 1.0
            timer.fontSize = 65
            
            botaoStart.size = CGSize(width:240, height:180)
            botaoStart.position.x = size.width/2
            botaoStart.position.y = size.height/2
            botaoStart.zPosition = 1.0
            
            startLabel.fontSize = 50
            startLabel.position.x = botaoStart.position.x
            startLabel.position.y = botaoStart.position.y - size.height * 0.03
            
            startLabel.zPosition = 2.0
            startLabel.horizontalAlignmentMode = .center
            startLabel.fontName = "Arial"
            startLabel.text = "START"
            startLabel.fontColor = UIColor.white
            
            
        }
        
//        for node in children{
//            repositionObj(node, oldSize: oldSize)
//        }
    }
    
    func repositionObj(_ node:SKNode, oldSize:CGSize){
        let xNovo = (node.position.x * size.width)/oldSize.width
        let yNovo = (node.position.y * size.height)/oldSize.height
        
        node.position = CGPoint(x: xNovo, y: yNovo)
    }
    
    func resizeByAltura(obj: SKSpriteNode, hNew: CGFloat){
        let wOld = obj.size.width
        let hOld = obj.size.height
        let wNew = hNew * (hOld / wOld)
        obj.size = CGSize(width: wNew, height: hNew)
    }
    
    
    func resizeObjectByWidth(obj:SKSpriteNode, wNew:CGFloat){
        let wOld = obj.size.width
        let hOld = obj.size.height
        let hNew = wNew * (hOld / wOld)
        obj.size = CGSize(width: wNew, height: hNew)
    }
    
    //Variavel para criar a linha.
    var nodeLinha:SKShapeNode?
    
    func touchDown(atPoint pos : CGPoint) {
        
        if(botaoStart.contains(pos)) && (existenciaStart){
            existenciaStart = false
            botaoStart.removeFromParent()
            startLabel.removeFromParent()
            timer.startWithDuration(duration: 75)
            run(sonzineo)


        }
        
        if(timer.hasFinished() != true) && (existenciaStart == false){
            if size.height > size.width {
                if(pos.y < size.height/2){
                    linha = CGMutablePath.init()
                    linha.move(to: pos)
                    nodeLinha = SKShapeNode()
                    if let nodeLinha = nodeLinha {
                        nodeLinha.path = linha
                        nodeLinha.strokeColor = .black
                        nodeLinha.lineWidth = 2
                        self.addChild(nodeLinha)
                    }
                }
            }
        
            else{
                if(pos.x > size.width/2){
                    linha = CGMutablePath.init()
                    linha.move(to: pos)
                    nodeLinha = SKShapeNode()
                    if let nodeLinha = nodeLinha {
                        nodeLinha.path = linha
                        nodeLinha.strokeColor = .black
                        nodeLinha.lineWidth = 2
                        self.addChild(nodeLinha)
                    }
                }
            }
        }
    }
    
    func touchMoved(toPoint pos : CGPoint) {
        
        
        
        if(timer.hasFinished() != true) && (existenciaStart == false){
            if size.height > size.width{
                if(pos.y < size.height/2){
                    if let nodeLinha = nodeLinha {
                        linha.addLine(to: pos)
                        nodeLinha.path = linha
                    }
                }
            }

            else{
                if(pos.x > size.width/2){
                    if let nodeLinha = nodeLinha {
                        linha.addLine(to: pos)
                        nodeLinha.path = linha
                    }
                }
            }
        }
    }
    
    func touchUp(atPoint pos : CGPoint) {
        
        if(timer.hasFinished() != true) && (existenciaStart == false){
            if size.height > size.width{
                if(pos.y < size.height/2){
                    if let nodeLinha = nodeLinha {
                        nodeLinha.path = linha
                    }
                }
            }

            else{
                if(pos.x > size.width/2){
                    if let nodeLinha = nodeLinha {
                        nodeLinha.path = linha
                    }
                }
            }
        }
    }
    
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {touchDown(atPoint: t.location(in: self))}
    }
    
    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchMoved(toPoint: t.location(in: self)) }
    }
    
    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }
    
    override public func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }
    
    override public func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        timer.update()
//
        if terminouTempo != true{
            if timer.hasFinished() == true{
                if size.height > size.width{
                    terminouTempo = true
                    caixaPreta.run(fadeout)
                    desenho1Min.size = CGSize(width: size.width - size.width * 0.06, height: size.height/2 - size.height * 0.03)
                    desenho1Min.position.x = campoCima.position.x
                    desenho1Min.position.y = campoCima.position.y
                    desenho1Min.zPosition = 0.4
                    self.addChild(desenho1Min)
                }
                else{
                    terminouTempo = true
                    caixaPreta.run(fadeout)
                    desenho1Min.size = CGSize(width: size.width/2 - size.width * 0.03, height: size.height - size.height * 0.06)
                    desenho1Min.position.x = campoCima.position.x
                    desenho1Min.position.y = campoCima.position.y
                    desenho1Min.zPosition = 0.4
                    self.addChild(desenho1Min)
                }
            }
        }
    }
    
}

//#-end-hidden-code
